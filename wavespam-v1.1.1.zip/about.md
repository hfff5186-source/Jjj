# Wave Spam

Wave autopilot for slopes. Press the **Spam** button in the pause menu to open the menu.

- **Bounce**: touches the slope above -> goes down, touches the slope below -> goes up.
- **Sensor**: looks ahead and steers through gaps.
- **CPS / Frames**: plain spam.
- **Player 1 / Player 2**: choose which wave the bot steers in dual.
- **Gravity Portals**: works when the wave is upside down.

Original by yausaf
