# Wave Spam

Wave autopilot for slopes. In the pause menu press **Spam** to open the menu (a check mark on the button means the mod is on), or **Settings** for every option.

- **Bounce**: touches the slope above -> goes down, touches the slope below -> goes up.
- **Sensor**: looks ahead and steers through gaps.
- **CPS / Frames**: plain spam.
- **Player 1 / Player 2**: choose which wave the bot steers in dual.
- **Gravity**: works when the wave is upside down.

Original by yausaf
