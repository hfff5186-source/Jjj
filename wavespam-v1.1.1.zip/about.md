# Wave Spam

Wave autopilot for slopes. A **Spam ON/OFF** button inside the level turns it on and off; all options are in the mod settings.

- **Bounce**: touches the slope above -> goes down, touches the slope below -> goes up.
- **Sensor**: looks ahead and steers through gaps.
- **CPS / Frames**: plain spam.
- **Player 1 / Player 2**: choose which wave the bot steers in dual.
- **Gravity Portals**: works when the wave is upside down.

Original by yausaf
