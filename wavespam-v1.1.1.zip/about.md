# Wave Spam

Wave autopilot. Press the small **Spam** button in the pause menu: it opens the mod menu with the **Enabled** switch and all the settings.

- **Sensor mode**: a box slightly bigger than the wave hitbox looks ahead and steers through gaps (mini and big wave).
- **CPS / Frames modes**: plain spam at a fixed rate.

Original by yausaf
