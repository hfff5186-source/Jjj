#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <algorithm>
#include <cmath>
#include <functional>
#include <string>
#include <vector>

using namespace geode::prelude;

// ======================================================================
//  GEOMETRY / PLANNING  (pure logic)
// ======================================================================
// ---- GEOMETRY BEGIN
struct Obs {
    int kind = 0;             // 0 rect, 1 triangle (slope), 2 circle
    CCRect rect;              // bounding box
    CCPoint tri[3];
    CCPoint center;
    float radius = 0.f;
};

using ObsList = std::vector<Obs const*>;

static float sgn(CCPoint a, CCPoint b, CCPoint c) {
    return (a.x - c.x) * (b.y - c.y) - (b.x - c.x) * (a.y - c.y);
}

static bool inTri(CCPoint p, CCPoint const* t) {
    float d1 = sgn(p, t[0], t[1]);
    float d2 = sgn(p, t[1], t[2]);
    float d3 = sgn(p, t[2], t[0]);
    bool neg = d1 < 0 || d2 < 0 || d3 < 0;
    bool pos = d1 > 0 || d2 > 0 || d3 > 0;
    return !(neg && pos);
}

static bool rectTri(CCRect const& r, CCPoint const* t) {
    float xs[3] = {r.getMinX(), r.getMidX(), r.getMaxX()};
    float ys[3] = {r.getMinY(), r.getMidY(), r.getMaxY()};
    for (float x : xs)
        for (float y : ys)
            if (inTri(CCPoint(x, y), t)) return true;
    for (int i = 0; i < 3; i++) {
        auto a = t[i];
        auto b = t[(i + 1) % 3];
        if (r.containsPoint(a)) return true;
        if (r.containsPoint(CCPoint((a.x + b.x) / 2.f, (a.y + b.y) / 2.f))) return true;
    }
    return false;
}

static bool circleRect(CCPoint c, float rad, CCRect const& r) {
    float cx = std::clamp(c.x, r.getMinX(), r.getMaxX());
    float cy = std::clamp(c.y, r.getMinY(), r.getMaxY());
    float dx = c.x - cx;
    float dy = c.y - cy;
    return dx * dx + dy * dy <= rad * rad;
}

static bool hitsList(ObsList const& list, CCRect const& s) {
    for (auto o : list) {
        if (o->rect.getMaxX() < s.getMinX() || o->rect.getMinX() > s.getMaxX() ||
            o->rect.getMaxY() < s.getMinY() || o->rect.getMinY() > s.getMaxY()) continue;
        if (o->kind == 0) return true;
        if (o->kind == 1 && rectTri(s, o->tri)) return true;
        if (o->kind == 2 && circleRect(o->center, o->radius, s)) return true;
    }
    return false;
}

static void filterObs(std::vector<Obs> const& cache, ObsList& out,
                      float minX, float maxX, float minY, float maxY) {
    out.clear();
    for (auto const& o : cache) {
        if (o.rect.getMaxX() < minX || o.rect.getMinX() > maxX ||
            o.rect.getMaxY() < minY || o.rect.getMinY() > maxY) continue;
        out.push_back(&o);
    }
}

// One wave that the bot is steering.
struct Agent {
    int player = 0;
    float cx0 = 0.f, cy0 = 0.f;   // sensor center now
    float dx = 0.f, d = 0.f;      // x step and |y| step per tick
    float hsx = 0.f, hsy = 0.f;   // sensor half size
    float sign = 1.f;             // +1 normal gravity, -1 upside down (holding moves it down)
    ObsList obs;                  // obstacles near this agent
};

// After i ticks with u of them "held", agent a is at
//   x = cx0 + i*dx,   y = cy0 + sign*(2u - i)*d
// All agents of a channel share the same hold sequence.
// Returns true = hold the button, false = release.
static bool planHold(std::vector<Agent> const& ag, int H, bool prevHold, float threshold) {
    int W = H + 2;
    static std::vector<double> cnt;
    static std::vector<int> dep;
    cnt.assign((H + 2) * W, 0.0);
    dep.assign((H + 2) * W, 0);

    for (int i = H; i >= 1; i--) {
        for (int u = 0; u <= i; u++) {
            bool bad = false;
            for (auto const& a : ag) {
                CCRect s(a.cx0 + i * a.dx - a.hsx,
                         a.cy0 + a.sign * static_cast<float>(2 * u - i) * a.d - a.hsy,
                         2.f * a.hsx, 2.f * a.hsy);
                if (hitsList(a.obs, s)) { bad = true; break; }
            }
            if (bad) continue;
            int idx = i * W + u;
            if (i == H) {
                cnt[idx] = 1.0;
                dep[idx] = 1;
            } else {
                cnt[idx] = cnt[(i + 1) * W + u + 1] + cnt[(i + 1) * W + u];
                dep[idx] = 1 + std::max(dep[(i + 1) * W + u + 1], dep[(i + 1) * W + u]);
            }
        }
    }

    double ch = cnt[W + 1], cr = cnt[W];
    int dh = dep[W + 1], dr = dep[W];

    if (ch > 0.0 || cr > 0.0) {
        double cur = prevHold ? ch : cr;
        double oth = prevHold ? cr : ch;
        if (cur <= 0.0) return !prevHold;               // blocked: must switch
        double share = oth / (cur + oth);
        double need = 0.5 + 0.5 * static_cast<double>(threshold);
        return share > need ? !prevHold : prevHold;     // hysteresis
    }
    if (dh != dr) return dh > dr;                       // no safe path: survive longest
    return prevHold;
}

struct Vote {
    int v = 0;            // +1 hold, -1 release, 0 no opinion
    bool urgent = false;  // the sensor really overlaps something
};

// Bounce: slope above -> go down, slope below -> go up.
// The next real step (forward and up / down) is checked.
static Vote bounceVote(Agent const& a, float probe, bool curUp) {
    CCRect here(a.cx0 - a.hsx, a.cy0 - a.hsy, 2.f * a.hsx, 2.f * a.hsy);
    CCRect up(a.cx0 + a.dx - a.hsx, a.cy0 - a.hsy + probe, 2.f * a.hsx, 2.f * a.hsy);
    CCRect dn(a.cx0 + a.dx - a.hsx, a.cy0 - a.hsy - probe, 2.f * a.hsx, 2.f * a.hsy);
    bool upHit = hitsList(a.obs, up);
    bool dnHit = hitsList(a.obs, dn);
    bool hereHit = hitsList(a.obs, here);

    Vote r;
    r.urgent = hereHit;
    bool have = false;
    bool wantUp = curUp;
    if (upHit && !dnHit) { wantUp = false; have = true; }
    else if (dnHit && !upHit) { wantUp = true; have = true; }
    else if (upHit && dnHit && hereHit) { wantUp = !curUp; have = true; } // squeezed

    if (have) r.v = (wantUp == (a.sign > 0.f)) ? 1 : -1;
    return r;
}
// ---- GEOMETRY END

// ======================================================================
//  STATE
// ======================================================================
namespace {
    struct Motion {
        bool haveLast = false;
        float lastX = 0.f, lastY = 0.f;
        float dx = 0.f;   // x movement per tick
        float k = 1.f;    // |dy| / dx of the wave
    };
    struct SpamState {
        bool down = false;
        float accum = 0.f;
        int frames = 0;
    };

    // channel 0 = player 1's input (or the shared input in a normal dual level)
    // channel 1 = player 2's input (2-player levels only)
    Motion s_motion[2];
    SpamState s_spam[2];
    bool s_userHold[2] = {false, false};  // the real finger
    bool s_hold[2] = {false, false};      // the bot's simulated button
    bool s_ctl[2] = {false, false};       // the bot steers this channel
    bool s_injecting = false;
    bool s_twoP = false;

    std::vector<Obs> s_cache;
    float s_cacheX = -1e9f;

    void resetState() {
        for (int i = 0; i < 2; i++) {
            s_motion[i] = Motion();
            s_spam[i] = SpamState();
            s_userHold[i] = false;
            s_hold[i] = false;
            s_ctl[i] = false;
        }
        s_injecting = false;
        s_twoP = false;
        s_cache.clear();
        s_cacheX = -1e9f;
    }
}

// ======================================================================
//  LEVEL CACHE
// ======================================================================
static void rebuildCache(GJBaseGameLayer* L, float px) {
    s_cache.clear();
    s_cacheX = px;
    if (!L->m_objects) return;

    for (auto obj : CCArrayExt<GameObject*>(L->m_objects)) {
        if (!obj) continue;
        auto type = obj->m_objectType;
        if (type != GameObjectType::Solid && type != GameObjectType::Hazard &&
            type != GameObjectType::Slope) continue;

        float ox = obj->getPositionX();
        if (ox < px - 120.f || ox > px + 700.f) continue;

        Obs o;
        o.rect = obj->getObjectRect();
        if (o.rect.size.width <= 0.f || o.rect.size.height <= 0.f) continue;

        if (type == GameObjectType::Slope) {
            o.kind = 1;
            CCPoint v[3] = {CCPoint(0, 0), CCPoint(1, 0), CCPoint(1, 1)};
            for (auto& p : v) {
                if (obj->m_isFlipX) p.x = 1.f - p.x;
                if (obj->m_isFlipY) p.y = 1.f - p.y;
            }
            int turns = ((static_cast<int>(std::lround(obj->getRotation() / 90.f)) % 4) + 4) % 4;
            for (int t = 0; t < turns; t++) {
                for (auto& p : v) {
                    float dx = p.x - 0.5f;
                    float dy = p.y - 0.5f;
                    p = CCPoint(0.5f + dy, 0.5f - dx);
                }
            }
            for (int i = 0; i < 3; i++) {
                o.tri[i] = CCPoint(
                    o.rect.origin.x + v[i].x * o.rect.size.width,
                    o.rect.origin.y + v[i].y * o.rect.size.height
                );
            }
        } else if (type == GameObjectType::Hazard && obj->m_objectRadius > 0.f) {
            o.kind = 2;
            o.center = obj->getPosition();
            o.radius = obj->m_objectRadius;
            o.rect = CCRect(o.center.x - o.radius, o.center.y - o.radius, o.radius * 2.f, o.radius * 2.f);
        }
        s_cache.push_back(o);
    }
}

static void ensureCache(GJBaseGameLayer* L, float px) {
    if (s_cacheX < -1e8f || px > s_cacheX + 250.f || px < s_cacheX - 5.f) {
        rebuildCache(L, px);
    }
}

// ======================================================================
//  INPUT
// ======================================================================
static void press(GJBaseGameLayer* L, int ch, bool down) {
    s_injecting = true;
    L->handleButton(down, 1, ch == 0);
    s_injecting = false;
}

static void releaseChannel(GJBaseGameLayer* L, int ch) {
    if (s_ctl[ch]) {
        s_ctl[ch] = false;
        s_hold[ch] = s_userHold[ch];
        press(L, ch, s_userHold[ch]);
    }
    if (s_spam[ch].down && !s_userHold[ch]) {
        s_spam[ch].down = false;
        press(L, ch, false);
    }
}

static void trackMotion(int pi, PlayerObject* p) {
    auto& m = s_motion[pi];
    float px = p->getPositionX();
    float py = p->getPositionY();
    if (m.haveLast) {
        float dx = px - m.lastX;
        float dy = py - m.lastY;
        if (dx > 0.001f && dx < 100.f) {
            m.dx = dx;
            float k = std::fabs(dy) / dx;
            if (k > 0.3f && k < 3.f) m.k = k;
        } else if (dx < -1.f || dx >= 100.f) {
            m.dx = 0.f;
            m.k = 1.f;
            s_cacheX = -1e9f;
        }
    }
    m.lastX = px;
    m.lastY = py;
    m.haveLast = true;
}

// ======================================================================
//  SENSOR BOX
// ======================================================================
struct Box {
    float hsx, hsy, ox, oy;
};

// sensor box = the game's own wave hitbox (red box) + margin
static Box makeBox(PlayerObject* p, float px, float py) {
    auto mod = Mod::get();
    float base = static_cast<float>(mod->getSettingValue<double>("hitbox-size"));
    float margin = static_cast<float>(mod->getSettingValue<double>("margin"));

    Box b{0.f, 0.f, 0.f, 0.f};
    bool got = false;
    if (mod->getSettingValue<bool>("auto-hitbox")) {
        CCRect r = p->getObjectRect();
        if (r.size.width > 0.5f && r.size.width < 60.f &&
            r.size.height > 0.5f && r.size.height < 60.f) {
            b.hsx = r.size.width / 2.f + margin;
            b.hsy = r.size.height / 2.f + margin;
            b.ox = r.getMidX() - px;
            b.oy = r.getMidY() - py;
            got = true;
        }
    }
    if (!got) {
        b.hsx = b.hsy = (base * p->m_vehicleSize) / 2.f + margin;
    }
    b.hsx = std::max(0.25f, b.hsx);
    b.hsy = std::max(0.25f, b.hsy);
    return b;
}

static bool makeAgent(PlayerObject* p, int pi, bool gravityOpt, Agent& a) {
    auto& m = s_motion[pi];
    if (m.dx <= 0.01f) return false;
    float px = p->getPositionX();
    float py = p->getPositionY();
    Box b = makeBox(p, px, py);
    a.player = pi;
    a.cx0 = px + b.ox;
    a.cy0 = py + b.oy;
    a.dx = m.dx;
    a.d = m.k * m.dx;
    a.hsx = b.hsx;
    a.hsy = b.hsy;
    a.sign = (gravityOpt && p->m_isUpsideDown) ? -1.f : 1.f;
    return true;
}

// draws the sensor box in the level so it can be compared with the red hitbox
static void drawSensor(GJBaseGameLayer* L, int pi, bool show, CCRect const& r) {
    if (!L->m_objectLayer) return;
    std::string id = pi == 0 ? "wavespam-debug-1" : "wavespam-debug-2";
    auto node = static_cast<CCDrawNode*>(L->m_objectLayer->getChildByID(id));
    if (!show) {
        if (node) node->removeFromParent();
        return;
    }
    if (!node) {
        node = CCDrawNode::create();
        node->setID(id);
        L->m_objectLayer->addChild(node, 1000);
    }
    node->clear();
    CCPoint v[4] = {
        CCPoint(r.getMinX(), r.getMinY()), CCPoint(r.getMaxX(), r.getMinY()),
        CCPoint(r.getMaxX(), r.getMaxY()), CCPoint(r.getMinX(), r.getMaxY())
    };
    ccColor4F fill = pi == 0 ? ccColor4F{0.f, 1.f, 0.f, 0.15f} : ccColor4F{1.f, 0.6f, 0.f, 0.15f};
    ccColor4F line = pi == 0 ? ccColor4F{0.f, 1.f, 0.f, 1.f} : ccColor4F{1.f, 0.6f, 0.f, 1.f};
    node->drawPolygon(v, 4, fill, 0.5f, line);
}

static void hideBoxes(GJBaseGameLayer* L) {
    drawSensor(L, 0, false, CCRect());
    drawSensor(L, 1, false, CCRect());
}

// ======================================================================
//  BOT
// ======================================================================
// Sensor / Bounce: steer by looking at the level
static void runAuto(GJBaseGameLayer* L, float dt, bool bounce, bool twoP, bool dual) {
    auto mod = Mod::get();
    bool useP[2] = {mod->getSettingValue<bool>("player1"), mod->getSettingValue<bool>("player2")};
    bool gravityOpt = mod->getSettingValue<bool>("gravity-portals");
    bool show = mod->getSettingValue<bool>("show-sensor");
    float threshold = std::clamp(static_cast<float>(mod->getSettingValue<double>("threshold")), 0.f, 1.f);
    float lookahead = static_cast<float>(mod->getSettingValue<double>("lookahead"));
    float extra = std::max(0.f, static_cast<float>(mod->getSettingValue<double>("touch-distance")));
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    std::vector<Agent> chan[2];
    for (int pi = 0; pi < 2; pi++) {
        auto p = pl[pi];
        if (!p || p->m_isDead || !p->m_isDart) continue;
        if (!useP[pi]) continue;
        if (pi == 1 && !dual) continue;
        Agent a;
        if (!makeAgent(p, pi, gravityOpt, a)) continue;
        chan[(twoP && pi == 1) ? 1 : 0].push_back(std::move(a));
    }

    // level data around the first steered player
    for (int c = 0; c < 2; c++) {
        if (!chan[c].empty()) {
            ensureCache(L, chan[c][0].cx0);
            break;
        }
    }

    bool shown[2] = {false, false};

    for (int c = 0; c < 2; c++) {
        if (c == 1 && !twoP) break;
        auto& agents = chan[c];

        if (agents.empty()) {
            releaseChannel(L, c);
            continue;
        }

        if (!s_ctl[c]) {
            s_ctl[c] = true;
            s_hold[c] = s_userHold[c];
        }

        bool hold = s_hold[c];

        if (!bounce) {
            int H = std::clamp(static_cast<int>(std::ceil(lookahead / std::max(dt, 0.0005f))), 4, 70);
            for (auto& a : agents) {
                filterObs(s_cache, a.obs,
                          a.cx0 - a.hsx, a.cx0 + H * a.dx + a.hsx,
                          a.cy0 - H * a.d - a.hsy, a.cy0 + H * a.d + a.hsy);
            }
            hold = planHold(agents, H, s_hold[c], threshold);
        } else {
            int pick = 0;
            bool pickUrgent = false;
            for (auto& a : agents) {
                float probe = extra + a.d;
                filterObs(s_cache, a.obs,
                          a.cx0 - a.hsx - 2.f, a.cx0 + a.dx + a.hsx + 2.f,
                          a.cy0 - a.hsy - probe - 2.f, a.cy0 + a.hsy + probe + 2.f);
                bool curUp = s_hold[c] ? (a.sign > 0.f) : (a.sign < 0.f);
                Vote v = bounceVote(a, probe, curUp);
                if (v.v == 0) continue;
                if (pick == 0 || (v.urgent && !pickUrgent)) {
                    pick = v.v;
                    pickUrgent = v.urgent;
                }
            }
            if (pick != 0) hold = pick > 0;
        }

        if (hold != s_hold[c]) {
            s_hold[c] = hold;
            press(L, c, hold);
        }

        for (auto& a : agents) {
            shown[a.player] = true;
            drawSensor(L, a.player, show,
                       CCRect(a.cx0 - a.hsx, a.cy0 - a.hsy, 2.f * a.hsx, 2.f * a.hsy));
        }
    }

    for (int pi = 0; pi < 2; pi++) {
        if (!shown[pi]) drawSensor(L, pi, false, CCRect());
    }
}

// CPS / Frames: plain spam
static void runSpam(GJBaseGameLayer* L, float dt, std::string const& mode, bool twoP, bool dual) {
    auto mod = Mod::get();
    bool useP[2] = {mod->getSettingValue<bool>("player1"), mod->getSettingValue<bool>("player2")};
    bool onlyWave = mod->getSettingValue<bool>("only-wave");
    bool holdMode = mod->getSettingValue<bool>("hold-to-spam");
    PlayerObject* pl[2] = {L->m_player1, L->m_player2};

    for (int c = 0; c < 2; c++) {
        if (c == 1 && !twoP) break;

        if (s_ctl[c]) releaseChannel(L, c); // came from Sensor / Bounce

        bool any = false, anyWave = false;
        for (int pi = 0; pi < 2; pi++) {
            if (!useP[pi]) continue;
            if (pi == 1 && !dual) continue;
            if (((twoP && pi == 1) ? 1 : 0) != c) continue;
            any = true;
            if (pl[pi] && !pl[pi]->m_isDead && pl[pi]->m_isDart) anyWave = true;
        }

        auto& sp = s_spam[c];
        bool active = any && (!onlyWave || anyWave) && (!holdMode || s_userHold[c]);

        if (!active) {
            if (sp.down && !s_userHold[c]) {
                sp.down = false;
                press(L, c, false);
            }
            continue;
        }

        bool toggle = false;
        if (mode == "Frames") {
            int n = std::max<int>(1, static_cast<int>(mod->getSettingValue<int64_t>("frames")));
            if (++sp.frames >= n) {
                sp.frames = 0;
                toggle = true;
            }
        } else {
            float cps = std::max(1.f, static_cast<float>(mod->getSettingValue<double>("cps")));
            float half = 1.f / (2.f * cps);
            sp.accum += dt;
            if (sp.accum >= half) {
                sp.accum -= half;
                if (sp.accum > half) sp.accum = 0.f;
                toggle = true;
            }
        }

        if (toggle) {
            sp.down = !sp.down;
            press(L, c, sp.down);
        }
    }
}

static void tick(GJBaseGameLayer* L, float dt) {
    auto p1 = L->m_player1;
    auto p2 = L->m_player2;
    if (!p1 || p1->m_isDead) return;

    trackMotion(0, p1);
    if (p2) trackMotion(1, p2);

    auto mod = Mod::get();
    bool twoP = L->m_levelSettings && L->m_levelSettings->m_twoPlayerMode;
    bool dual = p2 && p2->isVisible();
    s_twoP = twoP;

    if (!mod->getSettingValue<bool>("enabled")) {
        releaseChannel(L, 0);
        releaseChannel(L, 1);
        hideBoxes(L);
        return;
    }

    auto mode = mod->getSettingValue<std::string>("mode");
    if (mode == "Sensor") {
        runAuto(L, dt, false, twoP, dual);
    } else if (mode == "Bounce") {
        runAuto(L, dt, true, twoP, dual);
    } else {
        runSpam(L, dt, mode, twoP, dual);
        hideBoxes(L);
    }
}

// ======================================================================
//  HOOKS
// ======================================================================
class $modify(WaveSpamGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        if (!s_injecting && button == 1) {
            int c = (s_twoP && !isPlayer1) ? 1 : 0;
            s_userHold[c] = down;
            if (s_ctl[c]) return; // the bot is steering this input, ignore the finger
            s_spam[c].down = down;
            s_spam[c].accum = 0.f;
            s_spam[c].frames = 0;
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (!isHalfTick) tick(this, dt);
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(WaveSpamPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        resetState();

        auto offSpr = ButtonSprite::create("Spam OFF");
        auto onSpr = ButtonSprite::create("Spam ON");
        offSpr->setScale(0.45f);
        onSpr->setScale(0.45f);

        auto toggler = CCMenuItemExt::createToggler(onSpr, offSpr, [](CCMenuItemToggler* t) {
            Mod::get()->setSettingValue<bool>("enabled", !t->isToggled());
        });
        toggler->toggle(Mod::get()->getSettingValue<bool>("enabled"));

        auto menu = CCMenu::create();
        menu->addChild(toggler);
        menu->setPosition({75.f, CCDirector::get()->getWinSize().height - 25.f});
        m_uiLayer->addChild(menu, 100);

        return true;
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        resetState();
    }
};
