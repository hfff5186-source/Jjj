#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

using namespace geode::prelude;

// ---------------------------------------------------------------- state
namespace {
    bool s_userHolding = false;   // the real finger is on the screen
    bool s_injecting = false;     // we are sending a button ourselves
    bool s_spamDown = false;      // simulated button (spam modes)
    bool s_botDown = false;       // simulated button (sensor mode)
    bool s_sensorActive = false;  // the sensor is steering right now
    float s_accum = 0.f;
    int s_frames = 0;

    // motion measured from the player
    bool s_haveLast = false;
    float s_lastX = 0.f, s_lastY = 0.f;
    float s_dx = 0.f;             // x movement per call
    float s_k = 1.f;              // |dy| / dx of the wave

    struct Obs {
        int kind = 0;             // 0 rect, 1 triangle (slope), 2 circle
        CCRect rect;              // bounding box
        CCPoint tri[3];
        CCPoint center;
        float radius = 0.f;
    };
    std::vector<Obs> s_cache;
    std::vector<Obs const*> s_near;
    float s_cacheX = -1e9f;

    std::vector<double> s_cnt;
    std::vector<int> s_dep;

    void resetState() {
        s_userHolding = false;
        s_injecting = false;
        s_spamDown = false;
        s_botDown = false;
        s_sensorActive = false;
        s_accum = 0.f;
        s_frames = 0;
        s_haveLast = false;
        s_dx = 0.f;
        s_k = 1.f;
        s_cache.clear();
        s_cacheX = -1e9f;
    }
}

// ---------------------------------------------------------------- geometry
static float sgn(CCPoint a, CCPoint b, CCPoint c) {
    return (a.x - c.x) * (b.y - c.y) - (b.x - c.x) * (a.y - c.y);
}

static bool inTri(CCPoint p, CCPoint const* t) {
    float d1 = sgn(p, t[0], t[1]);
    float d2 = sgn(p, t[1], t[2]);
    float d3 = sgn(p, t[2], t[0]);
    bool neg = d1 < 0 || d2 < 0 || d3 < 0;
    bool pos = d1 > 0 || d2 > 0 || d3 > 0;
    return !(neg && pos);
}

static bool rectTri(CCRect const& r, CCPoint const* t) {
    float xs[3] = {r.getMinX(), r.getMidX(), r.getMaxX()};
    float ys[3] = {r.getMinY(), r.getMidY(), r.getMaxY()};
    for (float x : xs)
        for (float y : ys)
            if (inTri(CCPoint(x, y), t)) return true;
    for (int i = 0; i < 3; i++) {
        auto a = t[i];
        auto b = t[(i + 1) % 3];
        if (r.containsPoint(a)) return true;
        if (r.containsPoint(CCPoint((a.x + b.x) / 2.f, (a.y + b.y) / 2.f))) return true;
    }
    return false;
}

static bool circleRect(CCPoint c, float rad, CCRect const& r) {
    float cx = std::clamp(c.x, r.getMinX(), r.getMaxX());
    float cy = std::clamp(c.y, r.getMinY(), r.getMaxY());
    float dx = c.x - cx;
    float dy = c.y - cy;
    return dx * dx + dy * dy <= rad * rad;
}

static bool hitsNear(CCRect const& s) {
    for (auto o : s_near) {
        if (o->rect.getMaxX() < s.getMinX() || o->rect.getMinX() > s.getMaxX() ||
            o->rect.getMaxY() < s.getMinY() || o->rect.getMinY() > s.getMaxY()) continue;
        if (o->kind == 0) return true;
        if (o->kind == 1 && rectTri(s, o->tri)) return true;
        if (o->kind == 2 && circleRect(o->center, o->radius, s)) return true;
    }
    return false;
}

// ---------------------------------------------------------------- level cache
static void rebuildCache(GJBaseGameLayer* L, float px) {
    s_cache.clear();
    s_cacheX = px;
    if (!L->m_objects) return;

    for (auto obj : CCArrayExt<GameObject*>(L->m_objects)) {
        if (!obj) continue;
        auto type = obj->m_objectType;
        if (type != GameObjectType::Solid && type != GameObjectType::Hazard &&
            type != GameObjectType::Slope) continue;

        float ox = obj->getPositionX();
        if (ox < px - 120.f || ox > px + 700.f) continue;

        Obs o;
        o.rect = obj->getObjectRect();
        if (o.rect.size.width <= 0.f || o.rect.size.height <= 0.f) continue;

        if (type == GameObjectType::Slope) {
            o.kind = 1;
            CCPoint v[3] = {CCPoint(0, 0), CCPoint(1, 0), CCPoint(1, 1)};
            for (auto& p : v) {
                if (obj->m_isFlipX) p.x = 1.f - p.x;
                if (obj->m_isFlipY) p.y = 1.f - p.y;
            }
            int turns = ((static_cast<int>(std::lround(obj->getRotation() / 90.f)) % 4) + 4) % 4;
            for (int t = 0; t < turns; t++) {
                for (auto& p : v) {
                    float dx = p.x - 0.5f;
                    float dy = p.y - 0.5f;
                    p = CCPoint(0.5f + dy, 0.5f - dx);
                }
            }
            for (int i = 0; i < 3; i++) {
                o.tri[i] = CCPoint(
                    o.rect.origin.x + v[i].x * o.rect.size.width,
                    o.rect.origin.y + v[i].y * o.rect.size.height
                );
            }
        } else if (type == GameObjectType::Hazard && obj->m_objectRadius > 0.f) {
            o.kind = 2;
            o.center = obj->getPosition();
            o.radius = obj->m_objectRadius;
            o.rect = CCRect(o.center.x - o.radius, o.center.y - o.radius, o.radius * 2.f, o.radius * 2.f);
        }
        s_cache.push_back(o);
    }
}

// ---------------------------------------------------------------- input
static void press(GJBaseGameLayer* L, bool down) {
    s_injecting = true;
    L->handleButton(down, 1, true);
    s_injecting = false;
}

static void trackMotion(PlayerObject* p) {
    float px = p->getPositionX();
    float py = p->getPositionY();
    if (s_haveLast) {
        float dx = px - s_lastX;
        float dy = py - s_lastY;
        if (dx > 0.001f && dx < 100.f) {
            s_dx = dx;
            float k = std::fabs(dy) / dx;
            if (k > 0.3f && k < 3.f) s_k = k;
        } else if (dx < -1.f || dx >= 100.f) {
            s_dx = 0.f;
            s_k = 1.f;
            s_cacheX = -1e9f;
        }
    }
    s_lastX = px;
    s_lastY = py;
    s_haveLast = true;
}

// ---------------------------------------------------------------- sensor planner
// After i steps with j of them "up", the sensor center is
//   (px + i*dx, py + (2j - i)*d)
// We count how many safe paths exist for each first move.
static bool planMove(float px, float py, float dx, float d, int H,
                     float hsx, float hsy, float ox, float oy,
                     bool prevUp, float threshold) {
    float cx0 = px + ox, cy0 = py + oy;
    float minX = cx0 - hsx, maxX = cx0 + H * dx + hsx;
    float minY = cy0 - H * d - hsy, maxY = cy0 + H * d + hsy;

    s_near.clear();
    for (auto const& o : s_cache) {
        if (o.rect.getMaxX() < minX || o.rect.getMinX() > maxX ||
            o.rect.getMaxY() < minY || o.rect.getMinY() > maxY) continue;
        s_near.push_back(&o);
    }

    int W = H + 2;
    s_cnt.assign((H + 2) * W, 0.0);
    s_dep.assign((H + 2) * W, 0);

    for (int i = H; i >= 1; i--) {
        for (int j = 0; j <= i; j++) {
            CCRect s(cx0 + i * dx - hsx, cy0 + (2 * j - i) * d - hsy, 2.f * hsx, 2.f * hsy);
            if (hitsNear(s)) continue;
            int idx = i * W + j;
            if (i == H) {
                s_cnt[idx] = 1.0;
                s_dep[idx] = 1;
            } else {
                s_cnt[idx] = s_cnt[(i + 1) * W + j + 1] + s_cnt[(i + 1) * W + j];
                s_dep[idx] = 1 + std::max(s_dep[(i + 1) * W + j + 1], s_dep[(i + 1) * W + j]);
            }
        }
    }

    double cu = s_cnt[W + 1], cd = s_cnt[W];
    int du = s_dep[W + 1], dd = s_dep[W];

    if (cu > 0.0 || cd > 0.0) {
        double cur = prevUp ? cu : cd;
        double other = prevUp ? cd : cu;
        // current direction is blocked: must switch
        if (cur <= 0.0) return !prevUp;
        // otherwise only switch if the other direction is clearly better.
        // threshold 0 = switch as soon as the other is any better (lots of clicks)
        // threshold 1 = never switch unless forced (fewest clicks)
        double share = other / (cur + other);
        double need = 0.5 + 0.5 * static_cast<double>(threshold);
        return (share > need) ? !prevUp : prevUp;
    }
    // no safe path: take the one that survives longest
    if (du != dd) return du > dd;
    return prevUp;
}

struct Box {
    float hsx, hsy, ox, oy;
};

// sensor box = the game's own wave hitbox (red box) + margin
static Box makeBox(PlayerObject* p, float px, float py) {
    auto mod = Mod::get();
    float base = static_cast<float>(mod->getSettingValue<double>("hitbox-size"));
    float margin = static_cast<float>(mod->getSettingValue<double>("margin"));

    Box b{0.f, 0.f, 0.f, 0.f};
    bool got = false;
    if (mod->getSettingValue<bool>("auto-hitbox")) {
        CCRect r = p->getObjectRect();
        if (r.size.width > 0.5f && r.size.width < 60.f &&
            r.size.height > 0.5f && r.size.height < 60.f) {
            b.hsx = r.size.width / 2.f + margin;
            b.hsy = r.size.height / 2.f + margin;
            b.ox = r.getMidX() - px;
            b.oy = r.getMidY() - py;
            got = true;
        }
    }
    if (!got) {
        b.hsx = b.hsy = (base * p->m_vehicleSize) / 2.f + margin;
    }
    b.hsx = std::max(0.25f, b.hsx);
    b.hsy = std::max(0.25f, b.hsy);
    return b;
}

static void releaseControl(GJBaseGameLayer* L) {
    if (s_sensorActive) {
        s_sensorActive = false;
        s_botDown = s_userHolding;
        press(L, s_userHolding);
    }
    if (s_spamDown && !s_userHolding) {
        s_spamDown = false;
        press(L, false);
    }
}

static void runSensor(GJBaseGameLayer* L, float dt) {
    auto mod = Mod::get();
    auto p = L->m_player1;

    if (!p->m_isDart) {
        releaseControl(L);
        return;
    }

    if (!s_sensorActive) {
        s_sensorActive = true;
        s_botDown = s_userHolding;
    }

    if (s_dx <= 0.01f) return;

    float px = p->getPositionX();
    float py = p->getPositionY();

    if (s_cacheX < -1e8f || px > s_cacheX + 250.f || px < s_cacheX - 5.f) {
        rebuildCache(L, px);
    }

    float lookahead = static_cast<float>(mod->getSettingValue<double>("lookahead"));

    int H = std::clamp(static_cast<int>(std::ceil(lookahead / std::max(dt, 0.0005f))), 4, 70);
    float d = s_k * s_dx;

    Box bx = makeBox(p, px, py);
    float hsx = bx.hsx, hsy = bx.hsy, ox = bx.ox, oy = bx.oy;
    float threshold = std::clamp(static_cast<float>(mod->getSettingValue<double>("threshold")), 0.f, 1.f);
    bool wantUp = planMove(px, py, s_dx, d, H, hsx, hsy, ox, oy, s_botDown, threshold);
    if (wantUp != s_botDown) {
        s_botDown = wantUp;
        press(L, wantUp);
    }
}

// Bounce: when the sensor touches the slope above -> go down,
//         when it touches the slope below -> go up.
static void runBounce(GJBaseGameLayer* L) {
    auto mod = Mod::get();
    auto p = L->m_player1;

    if (!p->m_isDart) {
        releaseControl(L);
        return;
    }

    if (!s_sensorActive) {
        s_sensorActive = true;
        s_botDown = s_userHolding;
    }

    float px = p->getPositionX();
    float py = p->getPositionY();

    if (s_cacheX < -1e8f || px > s_cacheX + 250.f || px < s_cacheX - 5.f) {
        rebuildCache(L, px);
    }

    Box b = makeBox(p, px, py);
    float probe = std::max(0.f, static_cast<float>(mod->getSettingValue<double>("touch-distance")));
    float cx = px + b.ox;
    float cy = py + b.oy;

    s_near.clear();
    for (auto const& o : s_cache) {
        if (o.rect.getMaxX() < cx - b.hsx - 2.f || o.rect.getMinX() > cx + b.hsx + 2.f ||
            o.rect.getMaxY() < cy - b.hsy - probe - 2.f || o.rect.getMinY() > cy + b.hsy + probe + 2.f) continue;
        s_near.push_back(&o);
    }

    CCRect upR(cx - b.hsx, cy - b.hsy + probe, 2.f * b.hsx, 2.f * b.hsy);
    CCRect dnR(cx - b.hsx, cy - b.hsy - probe, 2.f * b.hsx, 2.f * b.hsy);
    bool upHit = hitsNear(upR);
    bool dnHit = hitsNear(dnR);

    bool wantUp = s_botDown;
    if (upHit && !dnHit) wantUp = false;          // slope above -> go down
    else if (dnHit && !upHit) wantUp = true;      // slope below -> go up
    else if (upHit && dnHit) wantUp = !s_botDown; // squeezed: alternate

    if (wantUp != s_botDown) {
        s_botDown = wantUp;
        press(L, wantUp);
    }
}

static void runSpam(GJBaseGameLayer* L, float dt, std::string const& mode) {
    auto mod = Mod::get();
    auto p = L->m_player1;

    if (s_sensorActive) releaseControl(L);

    bool onlyWave = mod->getSettingValue<bool>("only-wave");
    bool holdMode = mod->getSettingValue<bool>("hold-to-spam");
    bool active = (!onlyWave || p->m_isDart) && (!holdMode || s_userHolding);

    if (!active) {
        if (s_spamDown && !s_userHolding) {
            s_spamDown = false;
            press(L, false);
        }
        return;
    }

    bool toggle = false;
    if (mode == "Frames") {
        int n = std::max<int>(1, static_cast<int>(mod->getSettingValue<int64_t>("frames")));
        if (++s_frames >= n) {
            s_frames = 0;
            toggle = true;
        }
    } else {
        float cps = std::max(1.f, static_cast<float>(mod->getSettingValue<double>("cps")));
        float half = 1.f / (2.f * cps);
        s_accum += dt;
        if (s_accum >= half) {
            s_accum -= half;
            if (s_accum > half) s_accum = 0.f;
            toggle = true;
        }
    }

    if (toggle) {
        s_spamDown = !s_spamDown;
        press(L, s_spamDown);
    }
}

// ---------------------------------------------------------------- hooks
class $modify(WaveSpamGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        if (!s_injecting && button == 1 && isPlayer1) {
            s_userHolding = down;
            if (s_sensorActive) return; // the sensor is steering, ignore the finger
            s_spamDown = down;
            s_accum = 0.f;
            s_frames = 0;
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto p = m_player1;
        if (p && !p->m_isDead && !isHalfTick) {
            trackMotion(p);

            auto mod = Mod::get();
            if (mod->getSettingValue<bool>("enabled")) {
                auto mode = mod->getSettingValue<std::string>("mode");
                if (mode == "Sensor") runSensor(this, dt);
                else if (mode == "Bounce") runBounce(this);
                else runSpam(this, dt, mode);
            } else {
                releaseControl(this);
            }
        }
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(WaveSpamPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        resetState();
        return true;
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        resetState();
    }
};

class $modify(WaveSpamPause, PauseLayer) {
    // custom menu: ON/OFF, mode, touch distance, margin
    void openWavePanel() {
        if (auto old = this->getChildByID("wavespam-panel")) {
            old->removeFromParent();
            return;
        }

        auto win = CCDirector::get()->getWinSize();
        float cx = win.width / 2.f;
        float cy = win.height / 2.f;

        auto panel = CCLayer::create();
        panel->setID("wavespam-panel");

        auto bg = CCScale9Sprite::create("GJ_square01.png");
        bg->setContentSize({260.f, 190.f});
        bg->setPosition({cx, cy});
        panel->addChild(bg);

        auto menu = CCMenu::create();
        menu->setPosition({0.f, 0.f});
        panel->addChild(menu);

        auto addLabel = [&](char const* text, float x, float y, float scale, bool left) {
            auto l = CCLabelBMFont::create(text, "bigFont.fnt");
            l->setScale(scale);
            if (left) l->setAnchorPoint({0.f, 0.5f});
            l->setPosition({x, y});
            panel->addChild(l);
            return l;
        };

        addLabel("Wave Spam", cx, cy + 78.f, 0.6f, false);

        // row 1: Enabled
        addLabel("Enabled", cx - 110.f, cy + 46.f, 0.45f, true);
        auto offSpr = ButtonSprite::create("OFF");
        auto onSpr = ButtonSprite::create("ON");
        offSpr->setScale(0.5f);
        onSpr->setScale(0.5f);
        auto toggler = CCMenuItemExt::createToggler(onSpr, offSpr, [](CCMenuItemToggler* t) {
            Mod::get()->setSettingValue<bool>("enabled", !t->isToggled());
        });
        toggler->toggle(Mod::get()->getSettingValue<bool>("enabled"));
        toggler->setPosition({cx + 65.f, cy + 46.f});
        menu->addChild(toggler);

        // row 2: Mode (tap to change)
        addLabel("Mode", cx - 110.f, cy + 16.f, 0.45f, true);
        auto modeSpr = ButtonSprite::create(Mod::get()->getSettingValue<std::string>("mode").c_str());
        modeSpr->setScale(0.5f);
        auto modeBtn = CCMenuItemExt::createSpriteExtra(modeSpr, [modeSpr](auto) {
            static char const* modes[4] = {"Bounce", "Sensor", "CPS", "Frames"};
            auto cur = Mod::get()->getSettingValue<std::string>("mode");
            int idx = 0;
            for (int i = 0; i < 4; i++) if (cur == modes[i]) idx = i;
            idx = (idx + 1) % 4;
            Mod::get()->setSettingValue<std::string>("mode", modes[idx]);
            modeSpr->setString(modes[idx]);
        });
        modeBtn->setPosition({cx + 65.f, cy + 16.f});
        menu->addChild(modeBtn);

        // rows 3 and 4: number steppers
        auto addStepper = [&](char const* key, char const* name, float y, double step, double lo, double hi) {
            addLabel(name, cx - 110.f, y, 0.45f, true);

            auto val = addLabel(
                fmt::format("{:.1f}", Mod::get()->getSettingValue<double>(key)).c_str(),
                cx + 65.f, y, 0.45f, false
            );

            auto change = [val, key, lo, hi](double delta) {
                double v = Mod::get()->getSettingValue<double>(key) + delta;
                v = std::clamp(v, lo, hi);
                v = std::round(v * 10.0) / 10.0;
                Mod::get()->setSettingValue<double>(key, v);
                val->setString(fmt::format("{:.1f}", v).c_str());
            };

            auto minusSpr = ButtonSprite::create("-");
            minusSpr->setScale(0.5f);
            auto minus = CCMenuItemExt::createSpriteExtra(minusSpr, [change, step](auto) { change(-step); });
            minus->setPosition({cx + 25.f, y});
            menu->addChild(minus);

            auto plusSpr = ButtonSprite::create("+");
            plusSpr->setScale(0.5f);
            auto plus = CCMenuItemExt::createSpriteExtra(plusSpr, [change, step](auto) { change(step); });
            plus->setPosition({cx + 105.f, y});
            menu->addChild(plus);
        };

        addStepper("touch-distance", "Touch", cy - 14.f, 0.5, 0.0, 20.0);
        addStepper("margin", "Margin", cy - 44.f, 0.5, -10.0, 20.0);

        // close
        auto closeSpr = ButtonSprite::create("Close");
        closeSpr->setScale(0.5f);
        auto closeBtn = CCMenuItemExt::createSpriteExtra(closeSpr, [panel](auto) {
            panel->removeFromParent();
        });
        closeBtn->setPosition({cx, cy - 76.f});
        menu->addChild(closeBtn);

        this->addChild(panel, 200);
    }

    void customSetup() {
        PauseLayer::customSetup();

        auto winSize = CCDirector::get()->getWinSize();

        // button 1: the Geode settings list
        auto setSpr = ButtonSprite::create("Settings");
        setSpr->setScale(0.4f);
        auto setBtn = CCMenuItemExt::createSpriteExtra(setSpr, [](auto) {
            openSettingsPopup(Mod::get(), false);
        });
        setBtn->setPosition({0.f, 0.f});

        // button 2: our own menu, placed next to the settings button
        auto spamSpr = ButtonSprite::create("Spam");
        spamSpr->setScale(0.4f);
        auto spamBtn = CCMenuItemExt::createSpriteExtra(spamSpr, [this](auto) {
            this->openWavePanel();
        });
        spamBtn->setPosition({-58.f, 0.f});

        auto menu = CCMenu::create();
        menu->addChild(setBtn);
        menu->addChild(spamBtn);
        menu->setPosition({winSize.width - 40.f, winSize.height - 25.f});
        this->addChild(menu, 100);
    }
};
