# v1.2.1

- One small button in the pause menu that opens the mod menu (Enabled switch + settings)

# v1.2.0

- Settings and ON/OFF switch moved to a button in the pause menu

# v1.1.1

- Fix build: processCommands signature

# v1.1.0

- New Sensor mode: looks ahead for gaps and steers the wave (blocks, spikes, saws, slopes)

# v1.0.0

- First release
