# v2.0.3

- Required Geode version raised to 5.9.0 (fixes the packaging error about Zstd compression)

# v2.0.2

- Removed the custom font; the menu uses the game's font
- Fix build error

# v2.0.1

- Fix: pause menu could close the game when the custom font failed to load. The font is now checked first and falls back to the game's font; boxes fall back to plain rectangles
- New setting: Custom Font (on/off)

# v2.0.0

- Player 1 / Player 2 switches (dual and 2-player levels)
- Gravity portal support (inverted button when the wave is upside down)
- New custom menu with the uploaded font (Roboto Mono Italic), two columns: control and tuning
- Pause buttons restyled with the same font

# v1.5.3

- Bounce: no more early spam. Default margin 0 and touch distance 0 (it always looks exactly one step ahead); alternating only when the sensor really overlaps slopes on both sides
- New Show Sensor Box option (also in the Spam menu) to compare the sensor with the red hitbox

# v1.5.2

- Pause buttons moved to the left side of the pause screen

# v1.5.1

- Pause buttons moved left of the top-right icon button and drawn on top of other buttons

# v1.5.0

- New Bounce mode: touches the slope above -> goes down, touches the slope below -> goes up
- Custom menu (ON/OFF, mode, touch distance, margin) with its own button next to the Settings button in the pause menu

# v1.4.0

- Sensor now uses the wave's real hitbox (the red box) from the game, mini and big, plus the margin

# v1.3.1

- Sensor size can now go as low as 0.1 and margin can be negative, for very small gaps

# v1.3.0

- Sensor mode: new Switch Threshold setting to control how often it switches direction (fewer clicks)

# v1.2.1

- One small button in the pause menu that opens the mod menu (Enabled switch + settings)

# v1.2.0

- Settings and ON/OFF switch moved to a button in the pause menu

# v1.1.1

- Fix build: processCommands signature

# v1.1.0

- New Sensor mode: looks ahead for gaps and steers the wave (blocks, spikes, saws, slopes)

# v1.0.0

- First release
