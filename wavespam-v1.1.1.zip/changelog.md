# v1.4.0

- Sensor now uses the wave's real hitbox (the red box) from the game, mini and big, plus the margin

# v1.3.1

- Sensor size can now go as low as 0.1 and margin can be negative, for very small gaps

# v1.3.0

- Sensor mode: new Switch Threshold setting to control how often it switches direction (fewer clicks)

# v1.2.1

- One small button in the pause menu that opens the mod menu (Enabled switch + settings)

# v1.2.0

- Settings and ON/OFF switch moved to a button in the pause menu

# v1.1.1

- Fix build: processCommands signature

# v1.1.0

- New Sensor mode: looks ahead for gaps and steers the wave (blocks, spikes, saws, slopes)

# v1.0.0

- First release
